<div id="footer">
<!--Footer-->
<table width="100%" border="0">
  <tr>
    <td>Copyrights 2016.  SNT Media</td>
  </tr>
</table>

</div>
</div>
</body>

</html>
