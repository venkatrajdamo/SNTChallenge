<!DOCTYPE html>
<html>
<head>
<title>CNN Extract</title>
<link href="/CnnExtract/Style/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div id="container">
        <!--Header-->
        <div id="header">
            <div align="center">
              <p>SNT Media CNN Extraction</p>
              <p class="style3">Extract Contents</p>
            </div>
          </div>