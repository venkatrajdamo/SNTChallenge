<!DOCTYPE html>
<!--Any Exception occurred will be redirected to this page-->
<html>
<head>
<title>Error Page</title>
</head>

<body>
<?php echo $this->msg;
?>  
</body>

</html>
