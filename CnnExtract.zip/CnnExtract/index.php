<?php
//Every request will be redirect to this main page..
require 'BaseClass/HandleRequest.php';
require 'BaseClass/Controller.php';
require 'BaseClass/Model.php';
require 'BaseClass/View.php';
$app = new HandleRequest();
?>